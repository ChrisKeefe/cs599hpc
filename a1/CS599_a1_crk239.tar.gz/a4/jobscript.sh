#!/bin/bash
#SBATCH --account=cs599-spr21
#SBATCH --job-name=random1
#SBATCH --time=02:00				# 2 min
#SBATCH --mem=2000
#SBATCH --ntasks=50

COMMENT="disabling the following slurm directives to reduce wait time"
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1

PREFIX='/scratch/crk239/cs599hpc'
ASSIGN='1'
ACTIVITY='4'
INFILE=random_act${ACTIVITY}_crk239.c
OUTFILE=random${ACTIVITY}

module load openmpi

mpicc ${PREFIX}/a${ASSIGN}/a${ACTIVITY}/${INFILE} -lm -o ${PREFIX}/a${ASSIGN}/a${ACTIVITY}/${OUTFILE}

srun ${PREFIX}/a${ASSIGN}/a${ACTIVITY}/${OUTFILE}
